#include "ParInt.hh"
#include "CuaIOParInt.hh"
#include <queue>
#include <iostream>
using namespace std;


int main() {
  queue<ParInt> c, c1, c2;
  LlegirCuaParInt(c);
  int t1 = 0, t2 = 0;
  
  while (not c.empty()) {
    ParInt p = c.front();
    if (t1 <= t2) {
      c1.push(p);
      t1 += p.segon();
    }
    else {
      c2.push(p);
      t2 += p.segon();
    }    
    c.pop();
  }
  EscriureCuaParInt(c1);
  cout << endl;
  EscriureCuaParInt(c2);
}
  
  
  