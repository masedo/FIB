#include <queue>
#include "ParInt.hh"
using namespace std;
  void LlegirCuaParInt(queue<ParInt>& q);
  void EscriureCuaParInt(queue<ParInt> q);

