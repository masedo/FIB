#include "ParInt.hh"
#include "CuaIOParInt.hh"
#include <queue>
#include <iostream>
using namespace std;


int suma_temps_cua(queue<ParInt> c) {
  /* Pre: cert */
  /* Post: el resultat es la suma de les segones components */
        /* de tots els parells d'enters de la cua */
  int n = 0;
  while (not c.empty()) {
    n += c.front().segon();
    c.pop();
  }
  return n;
}

int main() {
  queue<ParInt> c, c1, c2;
  LlegirCuaParInt(c);
  
  while (not c.empty()) {
    if (suma_temps_cua(c1) <= suma_temps_cua(c2)) 
      c1.push(c.front());
    else c2.push(c.front());
    
    c.pop();
  }
  EscriureCuaParInt(c1);
  cout << endl;
  EscriureCuaParInt(c2);
}
  
  
  