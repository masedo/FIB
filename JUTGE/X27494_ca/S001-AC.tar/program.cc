#include <list>
#include <iostream>
using namespace std;


void buscar_nombre(list<int> &L, int n, list<int>::iterator &it2, bool &t) {
  t = false;
  it2 = L.begin();
  while (it2 != L.end() and not t) {
    if (*it2 == n) t = true;
    else ++it2;
  }
}

void min_max_mitja(const list<int> &L) {
  list<int>::const_iterator it = L.begin();
  if (not L.empty()) {
    int min = *it, max = *it;
    double suma = *it; ++it;
    for (; it != L.end(); ++it) {
      if (*it > max) max = *it;
      if (*it < min) min = *it;
      suma += double(*it);
    }
    cout << min << " " << max << " " << suma/L.size() << endl;
  }
  else cout << "0" << endl;
}

int main() {
  list<int> L;
  list<int>::iterator it = L.begin();
  int codi, nombre;
  cin >> codi >> nombre;
  while (codi != 0 or nombre != 0) {
    if (codi == -1) L.insert(it,nombre);
    else {
      list<int>::iterator it2;
      bool trobat;
      buscar_nombre(L,nombre,it2,trobat);
      if (trobat) it2 = L.erase(it2);
    }
    min_max_mitja(L);    
    cin >> codi >> nombre;
  }
}