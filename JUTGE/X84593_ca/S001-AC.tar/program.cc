#include <iostream>
#include "Estudiant.hh"
#include "Arbre.hh"
#include "ArbIOest.hh"
using namespace std;


void cerca_estudiant(Arbre<Estudiant> &A, int &dni, int &n, int &p, bool &t) {
  if (not A.es_buit() and not t) {
    if (A.arrel().consultar_DNI() == dni) {
      t = true;
      if (A.arrel().te_nota()) n = A.arrel().consultar_nota();
    }
    else {
      Arbre<Estudiant> a1, a2;
      A.fills(a1,a2);
      cerca_estudiant(a1,dni,n,p,t);
      if (not t) cerca_estudiant(a2,dni,n,p,t);
      if (t) ++p;
    }
  } 
}


int main() {
  Arbre<Estudiant> A;
  llegir_arbre_est(A, 0);
  
  int dni;
  while (cin >> dni) {
    Arbre<Estudiant> a(A);
    int nota = -1, prof = 0;
    bool trobat = false;
    
    cerca_estudiant(a,dni,nota,prof,trobat);
    if (trobat) {
      if (nota != -1) {
	cout << "L'estudiant " << dni << " té profunditat ";
	cout << prof << " i la seva nota és " << nota << endl;
      }
      else {
	cout << "L'estudiant " << dni << " té profunditat ";
	cout << prof << ", però no té nota" << endl;
      }      
    }
    else cout << "L'estudiant " << dni << " no hi és" << endl;
  }
}
