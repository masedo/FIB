#include <iostream>
#include "Arbre.hh"
#include "ArbIOparint.hh"
using namespace std;


void cerca_nombre(Arbre<Pari> &A, int n, int &prof, int &com, bool &t) {
  if (not A.es_buit() and not t) {
    if (A.arrel().first == n) {
      com = A.arrel().second;
      t = true;
    }
    else {
      Arbre<Pari> a1, a2;
      A.fills(a1,a2);
      cerca_nombre(a1,n,prof,com,t);
      if (not t) cerca_nombre(a2,n,prof,com,t);
      if (t) ++prof;
    }
  }
} 

int main() {
  Arbre<Pari> A;
  llegir_arbre_parint(A, 0);
  int n;
  while (cin >> n) {
    Arbre<Pari> a(A);
    int prof = 0, com;
    bool t = false;
    cerca_nombre(a,n,prof,com,t);
    if (t) cout << n << " " << com << " " << prof << endl;
    else cout << "-1" << endl;
  }
}
    
  