#include "Textos.hh"

 
string Textos::treure_cometes1(string &s) {
  int n = s.length();
  string s1(n-1,'x');
  if (s[0] == '"' and s[n-1] == '"') s1.pop_back();
  int r = 0;
  for (int i = 0; i < n; ++i) {
    if (s[i] != '"') {
      s1[r] = s[i];
      ++r;
    }
  }
  return s1;
}   



Textos::Textos() {
  text_triat = false;
}

Textos::~Textos(){}

void Textos::afegir_text(const Text &t) {
  bool error = false;
  map<Frase,map<vector<Frase>,Text> >::iterator it = textos.find(t.consultar_autor());
  if (it != textos.end()) {
    map<vector<Frase>,Text>::iterator it2 = ((*it).second).find(t.consultar_titol());
    if (it2 != ((*it).second).end()) error = true;
  }
  if (not error) {
    it = textos.find(t.consultar_autor());
    if (it != textos.end()) {
      ((*it).second).insert(make_pair(t.consultar_titol(),t));
    }
    else {
      map<vector<Frase>,Text> titol_text;
      titol_text.insert(make_pair(t.consultar_titol(),t));
      textos.insert(make_pair(t.consultar_autor(),titol_text));
    }
  }
  else cout<<"error"<<endl;
} 

void Textos::eliminar_text() {
  if (((*text_a).second).size() == 1) textos.erase(text_a);
  else ((*text_a).second).erase(triat);
  text_triat = false;
}

void Textos::substitueix(string &p1, string &p2, Text &t) {
  if (text_triat) {
    p1 = treure_cometes1(p1);
    p2 = treure_cometes1(p2);
    ((*triat).second).substitueix_paraula(p1,p2);  
    t = (*triat).second;
  }
}
    
bool Textos::hi_ha_text_triat() {
  return text_triat;
}
	
bool Textos::triar_text(istream &is, Text &t) {
  if (not textos.empty()) {
    string s;
    vector<string> v;
    is>>s;
    while (is>>s) {
      if ((s != "{") and (s != "}")) v.push_back(s);
    }
    map<Frase,map<vector<Frase>,Text> >::iterator it1 = textos.begin();
    map<vector<Frase>,Text>::iterator it2 = ((*it1).second).begin();
    map<Frase,map<vector<Frase>,Text> >::iterator trobat_aut;
    map<vector<Frase>,Text>::iterator trobat_text;
    int z = 0, n = v.size();
    while (z<2 and it1 != textos.end()) {
      bool b = true;
      int i = 0;
      while (b and i < n) {
	if (not ((*it2).second).hi_ha_paraula(v[i])) b = false;
	++i;
      }
      if (b) {
	++z;
	trobat_text = it2;
	trobat_aut = it1;
      }
      ++it2;
      if (it2 == ((*it1).second).end()) {
	++it1;
	if (it1 != textos.end()) it2 = ((*it1).second).begin();
      }
    }
    if (z == 1) {
      triat = trobat_text;
      text_a = trobat_aut;
      t = (*triat).second;
      text_triat = true;
      t.calcular_taula();
    }
    return z==1;
  }
  else return false;
}
	    
void Textos::textos_autor(istream &is) {
  string p;
  Frase a;
  is>>p;
  is>>p;
  while (p != "?") {
    int s = p.length()-1;
    if (p[0] == '"' or p[s] == '"') p = treure_cometes1(p);
    a.afegir_paraula(p);
    is>>p;
  }
  map<Frase,map<vector<Frase>,Text> >::iterator it1 = textos.find(a);
  for (map<vector<Frase>,Text>::iterator it2 = ((*it1).second).begin();it2 != ((*it1).second).end();++it2) {
    cout<<"\"";
    int n = ((*it2).first).size();
    for (int i = 0; i<n; ++i) {
      if (i > 0) cout << " ";
      ((*it2).first)[i].escriure_frase();
    }
    cout<<"\""<<endl;
  }
}


void Textos::tots_autors() {
  for (map<Frase,map<vector<Frase>,Text> >::iterator it1 = textos.begin();it1 != textos.end();++it1) {
    map<vector<Frase>,Text>::iterator it2 = ((*it1).second).begin();
    int x = 0;
    int numf = 0;
    int nump = 0;
    while (it2 != ((*it1).second).end()) {
      numf = numf + ((*it2).second).consultar_frases();
      nump = nump + ((*it2).second).consultar_paraules_text();
      ++it2;
      ++x;
    }
    ((*it1).first).escriure_frase();
    cout<<" "<<x<<" "<<numf<<" "<<nump<<endl;
  }
}


void Textos::tots_textos() {
  for (map<Frase,map<vector<Frase>,Text> >::const_iterator it1 = textos.begin();it1 != textos.end();++it1) {
    for (map<vector<Frase>,Text>::const_iterator it2 = ((*it1).second).begin();it2 != ((*it1).second).end();++it2) {
      ((*it1).first).escriure_frase();
      cout<<" \"";
      int n = ((*it2).first).size();
      for (int i = 0; i<n; ++i) {
	if (i > 0) cout << " ";
	((*it2).first)[i].escriure_frase();
      }
      cout<<"\""<<endl;
    }
  }
}