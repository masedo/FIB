#include "Text.hh"



//Operacions privades
struct par_freq { 
  int freq;
  string par;
  bool operator<(const par_freq &p) const {
    if (freq != p.freq) return freq > p.freq;
    else if (par.length() != p.par.length()) return par.length() < p.par.length();
    else return par < p.par;
  }
};


string Text::treure_cometes2(string &s) {
  int n = s.length();
  string s1(n-1,'x');
  int r = 0;
  for (int i = 0; i < n; ++i) {
    if (s[i] != '"') {
      s1[r] = s[i];
      ++r;
    }
  }
  return s1;
}  

void Text::calcular_taula() {
  int n = contingut.size();
    for (int i = 0; i < n; ++i) {
      vector<pair<string,int> > vec;
      vec = contingut[i].calcular_freq();
      int r = vec.size();
      for (int j = 0; j < r; ++j) {
	map<string,int>::iterator it = taula.find(vec[j].first);
	if (it != taula.end()) (*it).second += vec[j].second;
	else taula.insert(vec[j]);
      }
    }
    set<par_freq> S;
    map<string,int>::iterator it = taula.begin();
    while (it != taula.end()) {
      par_freq g;
      g.par = (*it).first;
      g.freq = (*it).second;
      S.insert(g);
      ++it;
    }
    taula_freq = S;    
}



//Constructora
Text::Text() {
  text_triat = false;
}



//Destructora
Text::~Text(){}



//Modificadores
void Text::substitueix_paraula(string& p1, string& p2) {
  int n = contingut.size();
  for (int i = 0; i < n; ++i) contingut[i].substitueix(p1,p2);
  calcular_taula();
}

void Text::triar_text() {
  text_triat = true; 
  calcular_taula();
}



//Consultores
Frase Text::consultar_autor() const{
  return autor;
}

vector<Frase> Text::consultar_titol() const{
  return titol;
}

vector<Frase> Text::contingut_interval(int x, int y) const{
  vector<Frase> aux(y-x+1);
  int i = 0;
  for (int j=x-1;j<y;++j) {
    aux[i] = contingut[j];
    ++i;
  }
  return aux;
}

int Text::consultar_frases() const{
  return contingut.size();
}

int Text::consultar_paraules_text() const{
  int suma = 0, n = contingut.size();
  for (int i = 0; i < n; ++i) {
    suma += contingut[i].nombre_paraules();
  }
  return suma;
}

bool Text::hi_ha_paraula(const string &s) {
  int n = titol.size(), i = 0;
  bool trobada = false;
  vector<string> v;
  v.push_back(s);
  while (not trobada and i < n) {
    if (titol[i].hi_ha_paraules_conj(v)) trobada = true;
    ++i;
  }
  if (not trobada) {
    trobada = autor.hi_ha_paraules_conj(v);
  }
  i = 0;
  n = contingut.size();
  while (not trobada and i < n) {
    if (contingut[i].hi_ha_paraules_conj(v)) trobada = true;
    ++i;
  }
  return trobada;
}

bool Text::es_text_triat() {
  return text_triat;
}

bool Text::interval_correcte(int x, int y) const{
  return (x>0 and x<=y and y<=contingut.size());
}

bool Text::operator<(const Text &t) const {
  vector<Frase> tit = t.consultar_titol();
  if (autor != t.consultar_autor()) {
    int x = contingut.size(), y = tit.size(), z;
    if (x < y) z = x;
    else z = y;
    for (int i = 0; i < z; ++i) {
      if (titol[i] != tit[i]) return titol[i] < tit[i];
    }
    return x < y;
  }
  else return autor < t.consultar_autor();
}



//Lectura i escritura
void Text::llegir_text(istream &is1, istream &is2) {
  string p;
  Frase f; 
  while (is1>>p) {
    int s = p.length()-1;
    if (p[0] == '"' or p[s] == '"') p = treure_cometes2(p);
    f.afegir_paraula(p);
    if (p[s] == '.') {
      titol.push_back(f);
      Frase f1;
      f = f1;
    }
  }
  titol.push_back(f);
    
  is2>>p;
  while (is2>>p) {
    int s = p.length()-1;
    if (p[0] == '"' or p[s] == '"') p = treure_cometes2(p);
    autor.afegir_paraula(p);
  }
  
  Frase f1;
  while (cin >> p and p != "****") {
    f1.afegir_paraula(p);
    int s = p.length()-1;
    if (p[s] == '.' or p[s] == '?' or p[s] == '!') {
      contingut.push_back(f1);
      Frase f2;
      f1 = f2;
    }
  }
}

void Text::titol_text() const {
  int n = titol.size();
  for (int i = 0; i < n; ++i) 
    titol[i].escriure_frase();
}

void Text::autor_text() const {
  autor.escriure_frase();
}

void Text::contingut_text() {
  int n = contingut.size();
  for (int i = 0; i < n; ++i) {
    cout<<i+1<<" ";
    contingut[i].escriure_frase();
    cout<<endl;
  }
}

void Text::frases_xy(string &lin) {
  istringstream is(lin);
  string p;
  is>>p;
  int x,y;
  is>>x; 
  is>>y;
  if (interval_correcte(x,y)) {
    for (int i = x-1; i < y; ++i) {
      cout << i+1 << " ";
      contingut[i].escriure_frase();
      cout << endl;
    }  
  }
  else cout<<"error"<<endl;
}  

void Text::nombre_frases() const{
  cout << contingut.size() << endl;
}

void Text::nombre_paraules_text() const{
  int suma = 0, n = contingut.size();
  for (int i = 0; i < n; ++i) { 
    suma += contingut[i].nombre_paraules();
  }
  cout << suma << endl;
}
  
void Text::taula_frequencies() {
  set<par_freq>::iterator it = taula_freq.begin();
  while (it != taula_freq.end()) {
    cout << (*it).par <<  " " << (*it).freq << endl;
    ++it;
  }
}
  
void Text::frases_expressio(const string &is) {
  int r = contingut.size();
  for (int i = 0; i < r; ++i) {
    if (contingut[i].compleix_expressio(is)) {
      cout << i+1 << " ";
      contingut[i].escriure_frase();
      cout << endl;
    }
  }
}

void Text::frases_paraula(string &lin) {
 istringstream is(lin);
 string s;
 is >> s;
 vector<string> paraules;
 is>>s;
 while (s != "?") {
   paraules.push_back(s);
   is>>s;
 }
 int n = paraules.size();
 paraules[0] = treure_cometes2(paraules[0]);
 paraules[n-1] = treure_cometes2(paraules[n-1]);
 n = contingut.size();
 for (int i = 0; i < n; ++i) {
   if (contingut[i].hi_ha_paraules_seq(paraules)) {
     cout << i+1 << " ";
     contingut[i].escriure_frase();
     cout << endl;
   }   
 }  
}