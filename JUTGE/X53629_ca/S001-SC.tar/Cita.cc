#include "Cita.hh"




    Cita::Cita(){}
      

    Cita::~Cita() {}
       
       
    Frase Cita::consultar_autor() const{
      return autor;
    }

    
    vector<Frase> Cita::consultar_contingut() const{
      return contingut;
    }
    

    vector<Frase> Cita::consultar_titol() const{
      return titol;
    }
    
    
    int Cita::consultar_in() const{
      return in;
    }
    
    
    int Cita::consultar_fi() const{
      return fi;
    }
 

    void Cita::llegir_cita(const vector<Frase> &t, const Frase &a, const vector<Frase> &c, int x, int y) {
      titol = t;
      autor = a;
      contingut = c;
      in = x;
      fi = y;
    }
    

    void Cita::escriure_autor() {
      autor.escriure_frase();
    }
    
    
    void Cita::escriure_titol() {
      int x = titol.size();
      for (int i=0; i<x; ++i) {
	if (i > 0) cout << " ";
	titol[i].escriure_frase();
      }
    }
    
    
    void Cita::escriure_contingut() {
      int x = contingut.size();
      int z = in;
      for (int i=0; i<x; ++i) {
	cout<<z<<" ";
	++z;
	contingut[i].escriure_frase();
	cout<<endl;
      }
    }
    
    
    void Cita::escriure_infi() {
      cout<<in<<"-"<<fi<<endl;
    }
    
    
    
    
    
    
    
    