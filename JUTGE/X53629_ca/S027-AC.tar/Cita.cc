#include "Cita.hh"


//Constructora
Cita::Cita(){}
  

  
//Destructora  
Cita::~Cita() {}
    
    
    
//Consultores    
Frase Cita::consultar_autor() const{
  return autor;
}

ConjuntFrase Cita::consultar_contingut() const{
  return contingut;
}

ConjuntFrase Cita::consultar_titol() const{
  return titol;
}

int Cita::consultar_in() const{
  return in;
}

int Cita::consultar_fi() const{
  return fi;
}



//Lectura i escritura
void Cita::llegir_cita(const ConjuntFrase &t, const Frase &a, const ConjuntFrase &c, int x, int y) {
  titol = t;
  autor = a;
  contingut = c;
  in = x;
  fi = y;
}

void Cita::escriure_autor() {
  autor.escriure_frase();
}

void Cita::escriure_titol() {
  titol.escriure_conjunt_frase();
}

void Cita::escriure_contingut() {
  int x = contingut.nombre_frases();
  int z = in;
  for (int i=0; i<x; ++i) {
    cout<<z<<" ";
    ++z;
    (contingut.consultar_frase(i+1)).escriure_frase();
    cout<<endl;
  }
}

void Cita::escriure_infi() {
  cout<<in<<"-"<<fi<<endl;
}