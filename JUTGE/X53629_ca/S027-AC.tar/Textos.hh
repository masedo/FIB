#ifndef TEXTOS_HH
#define TEXTOS_HH


#include "Text.hh"
#include "Frase.hh"
#include "ConjuntFrase.hh"
#ifndef NO_DIAGRAM
#include <string>
#include <map>
#include <sstream>
#endif


class Textos {
  // Tipus de modul: dades.
  // Descripcio del tipus: conté un conjunt de textos.
    
private:


    
    map<Frase,map<ConjuntFrase,Text> > textos;
    map<ConjuntFrase,Text>::iterator triat;
    map<Frase,map<ConjuntFrase,Text> >::iterator text_a;
    bool text_triat;
    static string treure_cometes1(string &s);

/*
     Invariant de la representació:
     - "textos" és un map que conté parells on l'autor es la clau i 
	el valor és un altre map on la clau és un titol i el valor 
	és el text. 
     - "textos" sempre esta ordenat alfabeticament per autors i el map
       del valor sempre esta ordenat alfabeticament per titol de cada text.
     - Si "text_triat" és cert, l'iterador "text_a" apunta a un text del 
       map d'un dels valors de "textos".
*/
        

public:

    //Constructora
  
    /** @brief Crea un conjunt de textos
	    \pre cert
	    \post el resultat es un conjunt buit de textos 
    */ 
    Textos();
     
    
    
    //Destructora

    ~Textos();
   
    
    
    //Modificadores
    
    /** @brief Afegeix un text al paràmetre implícit
	    \pre cert
	    \post s'ha afegit el text "t" al parametre implicit 
    */  
    void afegir_text(const Text &t);    
    
    /** @brief Elimina el text triat del paràmetre implícit
	    \pre "hi_ha_text_triat()" és cert
	    \post el text triat del parametre implicit ha quedat eliminat 
    */     
    void eliminar_text();
    
    /** @brief Substitueix una paraula per una altra en tot el text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post totes les paraules "p1" del text triar del paràmetre implícit han 
		  estat substituides per la paraula "p2"
    */     
    void substitueix(string &p1, string &p2);    
    
    
    
    //Consultores

    /** @brief Retorna l'autor del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és l'autor del text triat del P.I.
    */
    Frase consultar_autor_triat() const;

    /** @brief Retorna el titol del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és el titol del text triat del P.I.
    */    
    ConjuntFrase consultar_titol_triat() const;
 
    /** @brief Retorna el contingut de l'interval ["x","y"] del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és el contingut de l'interval ["x","y"] del text triat
    */    
    ConjuntFrase consultar_contingut_interval(int x, int y) const;
    
    /** @brief Retorna el nombre de frases que té el contingut del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és el nombre de frases del contingut del text triat
    */      
    int consultar_frases_cont();
    
    /** @brief Retorna el nombre de paraules del contingut del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és el nombre de paraules del contingut del text triat
    */      
    int consultar_paraules_cont() const;    
    
    /** @brief Diu si l'interval és correcte en el text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post El resultat és cer si l'interval ["x","y"] és correcte en el 
		  text triat del paràmetre implícit
    */
    bool interval_correcte_triat(int x,int y);
    
    /** @brief Diu si tenim un text seleccionat
	    \pre cert
	    \post el resultat es cert si hi ha un text triat, sino el resultat es 
	    fals
    */
    bool hi_ha_text_triat();

    /** @brief Retorna el text que conté les paraules que es passen
	    \pre cert
	    \post el resultat es cert si existeix un únic text que conté les paraules de 
		  "is", sino, el resultat es fals. Si es cert, "t" és igual al text seleccionat
    */  
    bool triar_text(istream &is);

    
    
    //Lectura i escritura
    
    /** @brief Escriu tots els titols dels textos de l'autor "is"
	    \pre cert
	    \post s'ha escrit tots els titols dels textos de l'autor "is" del parametre implicit
    */  
    void textos_autor(istream &is);

    /** @brief Escriu tots els títols i els autors de tots els textos del paràmetre implícit
	    \pre cert
	    \post s'ha escrit tots els titols i els autors de tots els textos del parametre implicit
    */  
    void tots_textos();
    
    /** @brief Escriu tots els autors que tenen text, el nombre de textos de cadascun,i el nombre total de 
		i el nombre total de paraules i frases d'aquests textos 
	    \pre cert
	    \post s'ha escrit els autors amb text, el nombre de textos de cadascun 
		  d'aquests autors, i el nombre total de paraules i frases d'aquests textos
    */   
    void tots_autors();   

    /** @brief Escriu el contingut del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post S'ha escrit el contingut del text triat
    */     
    void contingut_text_triat();

    /** @brief Escriu l'autor del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post 
    */
    void autor_text_triat();

    /** @brief Escriu la taula de freqüències del text triat
	    \pre "hi_ha_text_triat()" és cert
	    \post S'ha escrit la taula de freqüències del text triat
    */
    void taula_frequencies_triat();

    /** @brief Escriu les frases del contingut del text triat que compleixen l'expressió "l"
	    \pre "hi_ha_text_triat()" és cert
	    \post S'ha escrit les frases del contingut del text triat que compleixen l'expressió "l"
    */
    void frases_expressio_triat(string &l);

    /** @brief Escriu les frases del contingut del text triat que tene la sequüència "l"
	    \pre "hi_ha_text_triat()" és cert
	    \post S'ha escrit les frases del contingut del text triat que contenen la sequüència "l"
    */
    void frases_paraula_triat(string &l);

    /** @brief Escriu les frases del contingut del text triat de l'interval que conté "l"
	    \pre "hi_ha_text_triat()" és cert
	    \post S'ha escrit les frases del contingut del text triat de l'interval que conté "l"
    */
    void frases_xy_triat(string &l);
  
};
#endif