/**
 * @mainpage Exemple de diseny modular:  Gestió d'uns textos.
*/

/** @file main.cc
    @brief Programa principal per l'exercici <em>Gestió d'uns textos</em>.
*/

#include "Textos.hh"
#include "Text.hh"
#include "Cites.hh"
#ifndef NO_DIAGRAM
#include <sstream>
#include <iostream>
#include <string>
#endif
using namespace std;

/** @brief Programa principal per l'exercici <em>Gestió d'uns textos</em>.
*/
int main () 
{
string linia, p;
Textos tn;
Cites c;
getline(cin,linia);
while (linia=="") getline(cin,linia);
while (linia != "sortir") {
  istringstream iss(linia);
  iss>>p;
  if (p=="afegir") {  		
    cout<<linia<<endl;
    iss>>p;
    if (p=="text") {
      Text nou;
      getline(cin,linia);
      istringstream iss2(linia);
      nou.llegir_text(iss,iss2);
      tn.afegir_text(nou);
    }
    else if (p=="cita") {
      int x;      
      iss>>x;
      int y;
      iss>>y;
      if (tn.hi_ha_text_triat()) {
	if (tn.interval_correcte_triat(x,y)) c.afegir_cita_xy(tn.consultar_autor_triat(),tn.consultar_titol_triat(),tn.consultar_contingut_interval(x,y),x,y);
	else cout<<"error"<<endl;
      }
      else cout<<"error"<<endl;
    }
    cout<<endl;
  }
  else if (p=="info") { 	
    cout<<linia<<endl;
    iss>>p;
    if (p=="?") {
      if (tn.hi_ha_text_triat()) {
	c.info(tn.consultar_autor_triat(),tn.consultar_titol_triat(),tn.consultar_frases_cont(),tn.consultar_paraules_cont());
      }
      else cout<<"error"<<endl;
    }
    else if (p=="cita") {
      iss>>p;
      c.info_cita(p);
    }
    cout<<endl;
  }
  else if (p=="tots") {	
    cout<<linia<<endl;
    iss>>p;
    if  (p=="textos") {
      tn.tots_textos();
    }
    else if (p=="autors") {
      tn.tots_autors();
    }
    cout<<endl;
  }
  else if (p=="totes") {	
    cout<<linia<<endl;
    c.totes_cites();
    cout<<endl;
  }
  else if (p=="triar") {	
    cout<<linia<<endl;
    if (not tn.triar_text(iss)) cout<<"error"<<endl;
    cout<<endl;
  }
  else if (p=="contingut") {	
    cout<<linia<<endl;
    if (tn.hi_ha_text_triat()) {
	tn.contingut_text_triat();
      }
    else cout<<"error"<<endl;
    cout<<endl;
  }
  else if (p=="substitueix") { 	
    cout<<linia<<endl;
    string p1;
    iss>>p1;
    iss>>p;
    string p2;
    iss>>p2;
    if (tn.hi_ha_text_triat()) {
      tn.substitueix(p1,p2);
    }
    else cout<<"error"<<endl;
    cout<<endl;
  }
  else if (p=="frases") {  
    cout<<linia<<endl;
    iss>>p;
    if (p[0]=='(' or p[0]=='{') {
      if (tn.hi_ha_text_triat()) {
	linia.erase(0,7);
	linia.erase(linia.end()-2,linia.end());
	tn.frases_expressio_triat(linia);
      }
      else cout<<"error"<<endl;
    }
    else if (p[0]=='"') {
      if (tn.hi_ha_text_triat()) {
	tn.frases_paraula_triat(linia);
      }
      else cout<<"error"<<endl;
    }
    else {
      if (tn.hi_ha_text_triat()) {
	tn.frases_xy_triat(linia);
      }
      else cout<<"error"<<endl;
      }
      cout<<endl;
  }
  else if (p=="textos") {	
    cout<<linia<<endl;
    tn.textos_autor(iss);
    cout<<endl;
  }
  else if (p=="autor") {	
    cout<<linia<<endl;
      if (tn.hi_ha_text_triat()) {
	tn.autor_text_triat();
	cout<<endl;
      }
      else cout<<"error"<<endl;
      cout<<endl;
  }
  else if (p=="nombre") {
    cout<<linia<<endl;
    iss>>p;
    iss>>p;
    if (p=="frases") {
      if (tn.hi_ha_text_triat()) {
	cout<<tn.consultar_frases_cont()<<endl;
      }
      else cout<<"error"<<endl;
      }
    else if (p=="paraules") {
      if (tn.hi_ha_text_triat()) {
	cout<<tn.consultar_paraules_cont()<<endl;
      }
      else cout<<"error"<<endl;
      }
      cout<<endl;
  }
  else if (p=="taula") {
    cout<<linia<<endl;
    if (tn.hi_ha_text_triat()) {
      tn.taula_frequencies_triat();
    }
    else cout<<"error"<<endl;
    cout<<endl;
  }
  else if (p=="cites") {
    cout<<linia<<endl;
    iss>>p;
    if (p=="?") {
      if (tn.hi_ha_text_triat()) {
	c.cites(tn.consultar_autor_triat(),tn.consultar_titol_triat());
      }
      else cout<<"error"<<endl;
      }
    else if (p=="autor") {
      c.cites_autor(iss);
    }
    cout<<endl;
  }
  else if (p=="eliminar") {	
    cout<<linia<<endl;
    iss>>p;
    if (p=="text") {
      if (tn.hi_ha_text_triat()) {
	tn.eliminar_text();
      }
      else cout<<"error"<<endl;
      }
    else if (p=="cita") {
      iss>>p;
      c.eliminar_cita(p);
    }
    cout<<endl;
  }
  getline(cin,linia);
  while (linia == "") getline(cin,linia);  
}
}
