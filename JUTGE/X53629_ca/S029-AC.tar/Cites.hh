#ifndef CITES_HH
#define CITES_HH


#include "Cita.hh"
#include "Text.hh"



    class Cites {
      
  // Tipus de modul: dades.
  // Descripcio del tipus: conté un conjunt de Text.
    
private:

  struct ref {
   string inicials;
   int num;
   bool operator<(const ref &r) const {
     if (inicials != r.inicials) return inicials < r.inicials;
     else return num < r.num;
     }   
   };

  map<ref,bool> ult_cita;
  map<ref,Cita> c;

    /** @brief Treu les cometes d'una paraula
	    \pre Cert
	    \post Si "s" tenia cometes, s'han tret 
    */  
    static string treure_cometes3(string &s);

    /** @brief Descomposa una referència
	    \pre Cert
	    \post El resultat és el numero que tenia el string "s" al final
		  i "s" ha quedat modificat sense tenir aquest numero al final
    */
    static int descomposar_ref(string &s);

    /** @brief Retorna les inicials de l'autor "a"
	    \pre Cert
	    \post El resultat són les inicials de l'autor "a"
    */ 
    static string consultar_refi(const Frase &a);    
    
    /** @brief Retorna el numero de la referència
	    \pre Cert
	    \post El resultat és el numero que té la referència "n"
    */ 
    int consultar_refn(const string &n);
    
    /** @brief Diu si dues cites són diferents 
	    \pre Cert
	    \post El resultat és cert si no hi ha cap cita en el paràmetre implícit 
		  amb l'autor "a", el contingut "t", l'interval ["x","y"] i la referència "in"
    */ 
    bool cites_diferents(const ConjuntFrase &t, const Frase &a, int x, int y, const string &in);
    
    /** @brief Retorna el valor que li correspon a la referència "n"
	    \pre Cert
	    \post El resultat és el valor que li correspon a la referència "n"
    */ 
    int trobar_ref(const string &n);  

/* 
   Invariant de la representació: 
   -"c" és un map on la clau és una estructura que conté el nom de la cita 
    juntament amb un nombre i el valor és la cita
   -"c" sempre esta ordenat alfabèticament segons el nom de la cita
   -"ult_cita" és un map on la clau és el nom d'una cita amb el seu nombre 
    i el valor és un booleà que és cert només si la referència de la clau
    és l'ultima que s'ha modificat
*/

  
public:
    //Constructora

    /** @brief Es crea un conjunt de cites buit
	    \pre cert
	    \post el resultat és un conjunt de cites buit
    */    
    Cites();
    
    
    
    //Destructora

    ~Cites();
       
    
    
    //Modificadores

    /** @brief Afegeix una cita al parametre implicit
	    \pre Cert
	    \post S'ha afegit una cita al paràmetre implícit
    */       
    void afegir_cita_xy(const Frase &autor, const ConjuntFrase &titol, const ConjuntFrase &contingut, int x, int y);


    /** @brief Elimina la cita amb nom "s" del paràmetre implícit
	    \pre existeix la cita amb referencia "s" al parametre implicit
	    \post s'ha eliminat la cita amb referencia "s" del parametre implicit
    */       
    void eliminar_cita(string &s);
    
    

    // Lectura i escriptura

    /** @brief Escriu l'autor, títol, nombre de frases, nombre de paraules i cites del paràmetre implícit
	    \pre cert
	    \post s'ha escrit autor, titol, nombre de frases, nombre de paraules i cites associades al parametre implicit
    */    
    void info(const Frase &autor, const ConjuntFrase &titol, int nfrases, int npar); 
     
    /** @brief Escriu l'autor, titol, numero de la frase inicial i numero de la frase final i
		contingut de la frase o frases d'una cita amb nom "s"
	    \pre al parametre implicit existeix la cita amb referencia "s"
	    \post s'ha escrit l'autor, titol, numero de la frase inicial i numero de la frase final i
		  contingut de la frase o frases de la cita amb referència "s"
    */   
    void info_cita(string &s);

    /** @brief Escriu les cites de l'autor "is" amb la seva referència, el contingut de les frases i titol 
	      del text d'on provenen
	    \pre cert
	    \post s'ha escrit les cites del l'autor "is" amb la seva referencia, el contingut de les frases 
		i titol del text d’on provenen
    */       
    void cites_autor(istream &is);
    
    /** @brief Escriu totes les cites del text "t"
	    \pre cert
	    \post s'ha escrit totes les cites del text "t" (per
		  a cada cita se’n mostra la seva referencia, el contingut de les frases, autor i
		  tıtol del text d’on provenen)
    */       
    void cites(const Frase &a, const ConjuntFrase &t);

    /** @brief Escriu la informació de totes les cites
	    \pre cert
	    \post s'ha escrit totes les cites del parametre implicit (per a cada cita se’n
		  mostra la seva referencia, el contingut de les frases, autor i títol del text
		  d’on provenen)
    */       
    void totes_cites();

};
#endif
