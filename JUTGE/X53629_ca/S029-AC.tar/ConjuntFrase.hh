#ifndef ConjuntFrase_HH
#define ConjuntFrase_HH

#include "Frase.hh"


class ConjuntFrase {
  
  // Tipus de modul: dades
  // Descripcio del tipus: Conté una seqüència de frases
    
private:
  
  vector<Frase> c_frase;

  /*
    Invariant de la representació:
    -"c_frase" conté una seqüència de frases
  */

  
  
public:
    //Constructora
    /** @brief Es crea un conjunt de frases buit
	    \pre cert
	    \post El resultat es un conjunt de frases buit
    */  
    ConjuntFrase();

    
    
    //Destructora
    ~ConjuntFrase();
    
    
    
    //Modificadores    
    /** @brief Afegeix una frase al conjunt
	    \pre cert
	    \post S'ha afegit una frase al paràmetre impllícit
    */ 
    void afegir_frase(const Frase &s);
    
    /** @brief Substitueix totes les aparicions de la paraula p1 per p2
	    \pre Cert
	    \post Totes les aparicions de la paraula "p1" en el P.I.
		  han estat substituïdes per la paraula "p2"
    */     
    void substitueix_par(int pos, string p1, string p2);
    
    
    
    //Consultores
    /** @brief Retorna la frase x-èssima del conjunt
	    \pre 0 < "x" <= # de frases del P.I.
	    \post El resultat és la frase x-èssima del P.I.
    */ 
    Frase consultar_frase(int x) const;
    
    /** @brief Retorna el nombre de frases del conjunt
	    \pre Cert
	    \post El resuktat és el nombre de frases que té
		  el paràmetre impllícit
    */ 
    int nombre_frases() const;
              
    /** @brief Operador igual
	    \pre cert
	    \post El resultat és cert si totes les frases del ConjuntFrase
		  "f" són iguals a les del P.I. i estan en le mateix ordre
    */ 
    bool operator==(const ConjuntFrase &f) const;  
    
    /** @brief Operador igual
	    \pre Cert
	    \post El resultat és cert si el ConjutFrase "f" és menor
		  alfabèticament en l'ordre en que estan les frases
		  que el paràmetre implícit
    */ 
    bool operator<(const ConjuntFrase &f) const; 
 
     
    
    //Lectura i escritura
    /** @brief Escriu un conjut de frases
	    \pre Cert
	    \post S'ha escrit totes les frases del paràmetre implícit en 
		  l'ordre corresponent
    */ 
    void escriure_conjunt_frase() const;
    
};
#endif
