#ifndef CITA_HH
#define CITA_HH


#include "ConjuntFrase.hh"


    class Cita {
  // Tipus de modul: dades.
  // Descripcio del tipus: conté el titol, l'autor i l'interval
      //del text al que fa referència i el contingut de la cita
private:
    ConjuntFrase titol;
    Frase autor;
    ConjuntFrase contingut;
    int in, fi;
    string ref;
/*
  Invariant de la representació:
  -"titol" conté el titol del text al que fa referència la cita
  -"autor" conté l'autor del text al que fa referència la cita
  -"contingut" conté el contingut de l'interval ["in","fi"] del contingut del text
  -["in","fi"] és l'interval de frases al que fa referència la cita
    en el text.
  -"ref" és el nom/referència de la cita
*/
  
public:
    //Constructora
    Cita();
    /* Pre: cert */
    /* Post: el resultat es una cita buida */

    
    
    //Destructora
    ~Cita();
       

    
    //Consultores     
    /** @brief Retorna l'autor de la cita
	    \pre cert
	    \post El resultat es l'autor del parametre implicit
    */
    Frase consultar_autor() const; 
    
    /** @brief Retorna el contingut de la cita
	    \pre cert
	    \post El resultat es el contungut del parametre implicit
    */
    ConjuntFrase consultar_contingut() const;   

    /** @brief Retorna el titol de la cita
	    \pre cert
	    \post El resultat es el titol del parametre implicit
    */
    ConjuntFrase consultar_titol() const;

    /** @brief Retorna l'inici de l'interval del contingut de la cita
	    \pre Cert
	    \post El resultat és l'inici de 'interval del contingut del P.I.
    */
    int consultar_in() const;

    /** @brief Retorna el final de l'interval del contingut de la cita
	    \pre Cert
	    \post El resultat és el final de 'interval del contingut del P.I.
    */
    int consultar_fi() const;

    

    //Lectura i escriptura
    /** @brief Llegeix una cita
	    \pre "t" es el titol del text de la cita, a es l'autor del text de la cita i el contingut de la cita
		  esta preparat al canal d'entrada
	    \post El titol i l'autor del P.I. ha passat a ser "t" i "a" i el contingut del P.I. ha passat a ser 
		  el que s'ha entrat pel canal
    */
    void llegir_cita(const ConjuntFrase &t, const Frase &a, const ConjuntFrase &c, int x, int y);
    
    /** @brief Escriu l'autor de la cita
	    \pre Cert
	    \post S'ha escrit l'autor al qual es refereix el paràmetre implícit
    */
    void escriure_autor();
    
    /** @brief Escriu el titol de la cita
	    \pre Cert
	    \post S'ha escrit el titol del text al qual es refereix el paràmetre implícit 
    */
    void escriure_titol();    

    /** @brief Escriu el contingut de la cita
	    \pre Cert
	    \post S'ha escrit el contingut al que es refereix el paràmetre implícit
    */
    void escriure_contingut();
    
    /** @brief Escriu l'interval de la cita
	    \pre Cert
	    \post S'ha escrit l'interval al que es refereix el P.I.
    */
    void escriure_infi() ;    
    
};
#endif
