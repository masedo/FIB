#include "Frase.hh"



//Operacions privades
string Frase::treu_signes_puntuacio(const string &s) {
  int n = s.length();
  string s1;
  for (int i = 0; i < n; ++i) {
    char c = s[i];
    if ((c >= 'a' and c <= 'z') or (c >= 'A' and c <= 'Z') or (c >= '0' and c <= '9')) s1.push_back(c);  
  }
  return s1;
}

void Frase::expressions(const string &s, string &exp1, string &exp2, char &op) {
  stack<char> p;
  int n = 1;
  while (s[n] == ' ') ++n;
  p.push(s[n]);
  int in = n ,fi;
  while(not p.empty()) {
    ++n;
    if (s[n]=='(' or s[n]=='{') p.push(s[n]);
    else if (s[n]==')' or s[n]=='}') {
	if (p.top() == '(' and s[n]==')') p.pop();
	else if (p.top() == '{' and s[n]=='}') p.pop();
      }
  }
  fi = n;
  exp1 = s.substr(in,(fi-in+1));
  ++n;
  while (s[n] == ' ') ++n;
  op = s[n];
  ++n;
  while (s[n] == ' ') ++n;
  p.push(s[n]);
  in = n;
  while(not p.empty()) {
    ++n;
    if (s[n]=='(' or s[n]=='{') p.push(s[n]);
    else if (s[n]==')' or s[n]=='}') {
	if (p.top() == '(' and s[n]==')') p.pop();
	else if (p.top() == '{' and s[n]=='}') p.pop();
      }
  }
  fi = n;
  exp2 = s.substr(in,(fi-in+1));
}



//Constructora
Frase::Frase() {
  nparaules = 0;
}



//Destructora
Frase::~Frase(){}



//Modificadores
void Frase::afegir_paraula(const string &s) {
  if (s.length() == 1 and (s[0]==',' or s[0]=='.' or s[0]==';' or s[0]==':' or s[0]=='!' or s[0]=='?'))
    frase[frase.size()-1].push_back(s[0]);
  else frase.push_back(s);
  
  string s1 = treu_signes_puntuacio(s);
  if (not s1.empty()) {
    map<string,int>::iterator it = paraules.find(s1);
    if (it != paraules.end()) ++(*it).second;
    else paraules.insert(make_pair(s1,1));  
  }
  
  ++nparaules;  
}

void Frase::substitueix(string &s1, string &s2) {
  map<string,int>::iterator it1 = paraules.find(s1);
  if (s1 != s2 and it1 != paraules.end()) {
    map<string,int>::iterator it2 = paraules.find(s2);
    int apar = (*it1).second;
    paraules.erase(it1);
    if (it2 != paraules.end()) (*it2).second += apar;
    else paraules.insert(make_pair(s2,apar));
    int n = 0, h = 0;
    while (n < apar) {
      if (treu_signes_puntuacio(frase[h]) == s1) {
	++n;
	char c = frase[h][int(frase[h].length())-1];
	frase[h] = s2;
	if (c=='.' or c ==',' or c==';' or c==':' or c=='!' or c=='?') frase[h].push_back(c); 
      }
      ++h;
    }    
  }
}



//Consultores
bool Frase::compleix_expressio_simple(string &s) {
    s.erase(s.length()-1,1);
    s.erase(0,1);
    int n = s.length();
    vector<string> v;    
    string p;
    for (int i = 0; i < n; ++i) {
      if (s[i] != ' ') p.push_back(s[i]);
      else if (not p.empty()) {
	v.push_back(p);
	p.clear();
      }
    }
    if (not p.empty()) v.push_back(p);
    return hi_ha_paraules_conj(v);
}

bool Frase::compleix_expressio(string &is) { //recursiva
  if (is[0] == '{') return compleix_expressio_simple(is);
  else {
    string exp1, exp2;
    char c;
    bool cond1, cond2;
    expressions(is,exp1,exp2,c);
    cond1 = compleix_expressio(exp1);
    if (cond1 and c == '|') return true;
    if (not cond1 and c == '&') return false;
    cond2 = compleix_expressio(exp2);
    if (c == '|') return cond1 or cond2;
    else return cond1 and cond2;
  }
}

string Frase::consulta_paraula(int n) const{
 return frase[n]; 
}

vector<pair<string,int> > Frase::calcular_freq() {
  map<string,int>::iterator it = paraules.begin();
  vector<pair<string,int> > V;
  while (it != paraules.end()) {
    if (not (*it).first.empty()) V.push_back(*it);
    ++it;
  }
  return V;
}

bool Frase::hi_ha_paraules_seq(const vector<string> &v) {
  if (hi_ha_paraules_conj(v)) {
    int N = frase.size(), n = v.size(), j = 0;
    while ((j+n-1) < N) {
      if (treu_signes_puntuacio(frase[j]) == v[0]) {
	++j;
	bool t = true;
	int h = 1, r = j;	
	while (t and h < n) {
	  if (treu_signes_puntuacio(frase[r]) != v[h]) t = false;
	  ++h; 
	  ++r;
	}
	if (t) return true;    
      }
      else ++j;
    }
    return false;
  }
  else return false;  
}

bool Frase::hi_ha_paraules_conj(const vector<string> &v) {
  int n = v.size(), i = 0;
  bool trobades = true;
  while (trobades and i < n) {
    map<string,int>::iterator it = paraules.find(treu_signes_puntuacio(v[i]));
    if (it == paraules.end()) trobades = false;
    ++i;
  }
  return trobades;
}
  
int Frase::nombre_paraules() const{
  return nparaules;  
}

bool Frase::operator<(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules(), z;
  if (x<=y) z = x;
  else z = y;
  for (int i=0;i<z;++i) {
    if (frase[i] != f.consulta_paraula(i)) return frase[i] < f.consulta_paraula(i);
  }
  return x<y;
}

bool Frase::operator!=(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules();
  if (x != y) return true;
  for (int i=0;i<x;++i) {
    if (frase[i] != f.consulta_paraula(i)) return true;
  }
  return false;
}

bool Frase::operator==(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules();
  if (x != y) return false;
  for (int i=0;i<x;++i) {
    if (frase[i] != f.consulta_paraula(i)) return false;
  }
  return true;
}



//Lectura i escriptura
void Frase::escriure_frase() const{
  int n = frase.size();
  for (int i = 0; i < n; ++i) {
    if (i > 0) cout << " ";
    cout << frase[i];
  }
}