#include "ConjuntFrase.hh"


//Constructora
ConjuntFrase::ConjuntFrase() {}



//Destructora
ConjuntFrase::~ConjuntFrase(){}



//Modificadores

void ConjuntFrase::afegir_frase(const Frase &s) {
  c_frase.push_back(s);
}

void ConjuntFrase::substitueix_par(int pos, string p1, string p2) {
  c_frase[pos-1].substitueix(p1,p2);  
}



//Consultores

Frase ConjuntFrase::consultar_frase(int x) const{
  return c_frase[x-1];
}

int ConjuntFrase::nombre_frases() const{
  return c_frase.size();
}

bool ConjuntFrase::operator==(const ConjuntFrase &f) const {
  int x = c_frase.size(), y = f.nombre_frases();
  if (x != y) return false;
  for (int i=0;i<x;++i) {
    if (c_frase[i] != f.consultar_frase(i+1)) return false;
  }
  return true;
}

bool ConjuntFrase::operator<(const ConjuntFrase &f) const {
  int x = c_frase.size(), y = f.nombre_frases(), z;
  if (x<=y) z = x;
  else z = y;
  for (int i=0;i<z;++i) {
    if (c_frase[i] != f.consultar_frase(i+1)) return c_frase[i] < f.consultar_frase(i+1);
  }
  return x<y;
}

//Lectura i escritura

void ConjuntFrase::escriure_conjunt_frase() const{
  int n = c_frase.size();
  for (int i = 0; i < n; ++i) {
    if (i > 0) cout << " ";
    c_frase[i].escriure_frase();
  }
}