#include "Cites.hh"


//Operacions privades   
struct ref {
  string inicials;
  int num;
  bool operator<(const ref &r) const {
    if (inicials != r.inicials) return inicials < r.inicials;
    else  return num < r.num;
  }
};

string Cites::treure_cometes3(string &s) {
  int n = s.length();
  if (s[n-1] == '"') s.erase(n-1);
  if (s[0] == '"') s.erase(s.begin());
  return s;
}

int Cites::descomposar_ref(string &s) {
  int x = s.length();
  int i = 0;
  string aux;
  while (s[i] < '1' or s[i] > '9') {
    aux.push_back(s[i]);
    ++i;
  }
  int j = 0;
  string num(x-i,'x');
  while (i<x) {
    num[j] = s[i];
    ++j;
    ++i;
  }
  int n;
  istringstream convert(num);
  convert >> n;
  s = aux;
  return n;
}    

string Cites::consultar_refi(const Frase &a) {
  int n = a.nombre_paraules();
  string autor(n,'x');
  for (int j=0;j<n;++j) {
    autor[j] = (a.consulta_paraula(j+1))[0];
  }
  return autor;
}

int Cites::consultar_refn(const string &n) {
  ref r;
  r.inicials = n;
  r.num = 1;
  map<ref,bool>::iterator i=ult_cita.find(r);
  bool acaba = false;
  int m = 1;
  while (not acaba and i != ult_cita.end()) {
    if (n != ((*i).first).inicials) acaba = true;
    if (not acaba) {
      ++m;
      ++i;
    }
  }
  return m;
} 

bool Cites::cites_diferents(const ConjuntFrase &t, const Frase &a, int x, int y, const string &in) {
  ref r;
  r.inicials = in;
  r.num = trobar_ref(in);
  map<ref,Cita>::const_iterator i=c.find(r);
  bool acaba = false;
  while (not acaba and i != c.end()) {
    if (in != ((*i).first).inicials) acaba = true;
    if (not acaba) {
	if (a == ((*i).second).consultar_autor()) {
	if (t == ((*i).second).consultar_titol()) {
	  if (x == ((*i).second).consultar_in() and y == ((*i).second).consultar_fi()) return false;
	}
      }
      ++i;
    }
  }
  return true;
}

int Cites::trobar_ref(const string &n) {
  ref r;
  r.inicials = n;
  r.num = 1;
  map<ref,bool>::iterator i=ult_cita.find(r);
  bool acaba = false;
  while (not acaba and i != ult_cita.end()) {
    if ((*i).second) acaba = true;
    else ++i;
  }
  if (i != ult_cita.end()) return ((*i).first).num;
  else return r.num;
}


//Constructora
Cites::Cites(){}



//Destructora
Cites::~Cites(){}



//Modificadores
void Cites::afegir_cita_xy(const Frase &a, const ConjuntFrase &t, const ConjuntFrase &cont, int x, int y){
    string in;
    in = consultar_refi(a);
    if (cites_diferents(t, a, x, y, in)) {
      Cita c1;
      c1.llegir_cita(t, a, cont, x, y);
      int n;
      n = consultar_refn(in);
      ref r;
      r.inicials = in;
      r.num = n;
      c.insert(make_pair(r,c1));
      ult_cita.insert(make_pair(r,true));
    }
    else cout<<"error"<<endl;
  }   
  
void Cites::eliminar_cita(string &s){
  int n;
  n = descomposar_ref(s);
  s = treure_cometes3(s);
  ref r;
  r.inicials = s;
  r.num = n;
  map<ref,Cita>::iterator i=c.find(r);
  if (i != c.end()) c.erase(i);
  else cout<<"error"<<endl;
  map<ref,bool>::iterator u=ult_cita.find(r);
  if (u != ult_cita.end()) (*u).second = false;
}



// Lectura i escriptura
void Cites::info(const Frase &a, const ConjuntFrase &t, int nfrases, int npar) {
  a.escriure_frase();
  cout<<" \"";
  t.escriure_conjunt_frase();
  cout<<"\" ";
  cout<<nfrases<<" "<<npar<<endl;
  string in;
  in = consultar_refi(a);
  ref r;
  r.inicials = in;
  r.num = trobar_ref(in);
  map<ref,Cita>::iterator i=c.find(r);
  bool acaba = false;
  cout<<"Cites Associades:"<<endl;
  while (not acaba and i != c.end()) {
    if (in != ((*i).first).inicials) acaba = true;
    else {
      if (a == ((*i).second).consultar_autor()) {
	if (t == ((*i).second).consultar_titol()) {
	    cout<<(*i).first.inicials<<(*i).first.num<<endl;
	    ((*i).second).escriure_contingut();
	}
      }
      ++i;
    }
  }
}

void Cites::info_cita(string &s){
  int n;
  n = descomposar_ref(s);
  s = treure_cometes3(s);
  ref r;
  r.inicials = s;
  r.num = n;
  map<ref,Cita>::iterator i = c.find(r);
  if (i != c.end()) {
    ((*i).second).escriure_autor();
    cout<<" \"";
    ((*i).second).escriure_titol();
    cout<<"\""<<endl;
    ((*i).second).escriure_infi();
    ((*i).second).escriure_contingut();
  }
  else cout<<"error"<<endl;
}
    
void Cites::cites_autor(istream &is) {
  string p;
  Frase autor;
  is>>p;
  while (p != "?") {
    if (p[0] == '"' or p[p.length()-1] == '"') p = treure_cometes3(p);
    autor.afegir_paraula(p);
    is>>p;
  }
  string in;
  in = consultar_refi(autor);
  ref r;
  r.inicials = in;
  r.num = trobar_ref(in);
  map<ref,Cita>::iterator i=c.find(r);
  bool acaba = false;
  while (not acaba and i != c.end()) {
    if (in != ((*i).first).inicials) acaba = true;
    else {
      if (autor == ((*i).second).consultar_autor()) {
	cout<<(*i).first.inicials<<(*i).first.num<<endl;
	((*i).second).escriure_contingut();
	cout<<"\"";
	((*i).second).escriure_titol();
	cout<<"\""<<endl;
      }
      ++i;
    }
  }
}
    
void Cites::cites(const Frase &a, const ConjuntFrase &t) {
  string in;
  in = consultar_refi(a);
  ref r;
  r.inicials = in;
  r.num = trobar_ref(in);
  map<ref,Cita>::iterator i=c.find(r);
  bool acaba = false;
  while (not acaba and i != c.end()) {
    if (in != ((*i).first).inicials) acaba = true;
    else {
      if (a == ((*i).second).consultar_autor()) {
	if (t == ((*i).second).consultar_titol()) {
	  cout<<(*i).first.inicials<<(*i).first.num<<endl;
	  ((*i).second).escriure_contingut();
	  ((*i).second).escriure_autor();
	  cout<<" \"";
	  ((*i).second).escriure_titol();
	  cout<<"\""<<endl;
	}
      }
      ++i;
    }
  }
}  
  
void Cites::totes_cites() {
  for (map<ref,Cita>::iterator i=c.begin();i != c.end(); ++i) {
    cout<<(*i).first.inicials<<(*i).first.num<<endl;
    ((*i).second).escriure_contingut();
    ((*i).second).escriure_autor();
    cout<<" \"";
    ((*i).second).escriure_titol();
    cout<<"\""<<endl;
  }
}