#ifndef TEXTOS_HH
#define TEXTOS_HH


#include "Text.hh"
#include "Frase.hh"
#ifndef NO_DIAGRAM
#include <string>
#include <map>
#include <sstream>
#endif


class Textos {
    
private:


    
    map<Frase,map<vector<Frase>,Text> > textos;
    map<vector<Frase>,Text>::iterator triat;
    map<Frase,map<vector<Frase>,Text> >::iterator text_a;
    bool text_triat;
    static string treure_cometes1(string &s);


public:

    //Constructores
  
/** @brief Crea un conjunt de textos
	\pre cert
	\post el resultat es un conjunt buit de textos 
*/ 
    Textos();
     
    
    
    //Destructora

    ~Textos();
   
    
    
    //Modificadores
    
/** @brief Afegeix un text al paràmetre implícit
	\pre cert
	\post s'ha afegit el text "t" al parametre implicit 
*/  
    void afegir_text(const Text &t);
    
    
/** @brief Elimina el text triat del paràmetre implícit
	\pre cert
	\post el text triat del parametre implicit ha quedat eliminat 
*/     
    void eliminar_text();

    
/** @brief Substitueix una paraula per una altra en tot el text triat
	\pre 
	\post totes les paraules "p1" del text triar del paràmetre implícit han 
	      estat substituides per la paraula "p2"
*/     
    void substitueix(string &p1, string &p2, Text &t);    
    
    
    
    //Consultores

/** @brief Diu si tenim un text seleccionat
	\pre cert
	\post el resultat es cert si hi ha un text triat, sino el resultat es 
	fals
*/
    bool hi_ha_text_triat();
           

/** @brief Retorna el text que conté les paraules que es passen
	\pre cert
	\post el resultat es cert si existeix un únic text que conté les paraules de 
	      "is", sino, el resultat es fals. Si es cert, "t" és igual al text seleccionat
*/  
    bool triar_text(istream &is, Text &t); //t = *it//

    
    
    //Lectura i escritura
    
/** @brief Escriu tots els titols dels textos de l'autor "is"
	\pre cert
	\post s'ha escrit tots els titols dels textos de l'autor "is" del parametre implicit
*/  
    void textos_autor(istream &is);

    
/** @brief Escriu tots els títols i els autors de tots els textos del paràmetre implícit
	\pre cert
	\post s'ha escrit tots els titols i els autors de tots els textos del parametre implicit
*/  
    void tots_textos();

    
/** @brief Escriu tots els autors que tenen text, el nombre de textos de cadascun,i el nombre total de 
	    i el nombre total de paraules i frases d'aquests textos 
	\pre cert
	\post s'ha escrit els autors amb text, el nombre de textos de cadascun 
              d'aquests autors, i el nombre total de paraules i frases d'aquests textos
*/   
    void tots_autors();   
 
};
#endif


 
