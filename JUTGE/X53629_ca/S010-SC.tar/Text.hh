#ifndef TEXT_HH
#define TEXT_HH


#include "Frase.hh"
#ifndef NO_DIAGRAM
#include <string>
#include <set>
#include <map>
#include <vector>
#include <sstream>
#include <iostream>
#endif


class Text {
  
    // Tipus de modul: dades.
    // Descripcio del tipus: conté totes les frases d'un text.
    
private:
 
    vector<Frase> titol; 
    Frase autor;
    vector<Frase> contingut;
      
    struct par_freq { 
      int freq;
      string par;
      bool operator<(const par_freq &p) const {
	if (freq != p.freq) return freq > p.freq;
	else if (par.length() != p.par.length()) return par.length() < p.par.length();
	else return par < p.par;
      }
    };
      
    set<par_freq> taula_freq;
    map<string,int> taula;
    bool taula_actualitzada;
    /*
     Invariant de la representació:
     -
     -    
    */
    
    
    
    /** @brief Treu les cometes d'una paraula
	\pre Cert
	\post El resultat és un string igual a "s" però sense cometes
    */
    static string treure_cometes2(string &s);
     

public:

    //Constructora

    /** @brief Es crea un text buit
	    \pre cert
	    \post el resultat es text buit
    */
    Text();

    
    
    //Destructora

    ~Text();
     
    
    
    //Modificadores
   
    /** @brief Substitueix una paraula per una altra en tot el text
	    \pre cert
	    \post totes les paraules "p1" del paràmetre implícit han estat substituides per la paraula "p2"
    */         
    void substitueix_paraula(string& p1, string& p2);    
      
    
    
    /** @brief Calcula la taula de freqüències
	\pre Cert
	\post S'ha calculat la taula de freqüències del P.I.
    */
    void calcular_taula(); 
    
    
    //Consultores  

    /** @brief Retorna l'autor del text
	    \pre cert
	    \post El resultat és l'autor del paràmetre implícit
    */     
    Frase consultar_autor() const;


    /** @brief Retorna el titol del text
	    \pre cert
	    \post El resultat és el titol del paràmetre implícit
    */
    vector<Frase> consultar_titol() const;  
    
    
    /** @brief Retorna el contingut de l'interval ["x","y"] del text 
	    \pre Cert
	    \post El resultat és el contingut de l'interval ["x","y"] del P.I.
    */
    vector<Frase> contingut_interval(int x, int y) const;  

    
    /** @brief Retorna el numero de frases
	    \pre Cert
	    \post El resultat és el numero de farses del paràmetre implícit
    */    
    int consultar_frases() const;

    
    /** @brief Retorna el numero de paraules del text
	    \pre Cert
	    \post El resultat és el numero de paraules que té el P.I.
    */    
    int consultar_paraules_text() const;
  
    
    /** @brief Diu si hi ha una paraula "s" en el text
	    \pre Cert
	    \post El resultat és cert si hi ha una paraula igual a "s" en el 
		  paràmetre implícit i és fals altrament
    */    
    bool hi_ha_paraula(const string &s);

    
    /** @brief Ens diu si l'interval ["x","y"] és correcte
	    \pre Cert
	    \post EL resultat és cert si 0 < x < y < #de frases del P.I.
    */    
    bool interval_correcte(int x, int y) const;
  
    
    /** @brief Operador menor
	    \pre Cert
	    \post El resultat és cert si l'autor del P.I. és més petit alfabeticament	
		  que l'autor de "t". Si l'autor dels dos és el mateix el resultat
		  és cert si el titol del P.I. és menor alfabeticament que el titol
		  del text "t". El resultat és fals altrament.
    */    
    bool operator<(const Text &t) const;
    
    
 
    //Lectura i escritura

    /** @brief Llegeix el titol, l'autor i el contingut del text
	    \pre "is1" es el titol, "is2" es l'autor i el contingut del text esta preparat al canal d'entrada
	    \post s'ha llegit el titol, l'autor i el text del parametre implicit
    */    
    void llegir_text(istream &is1, istream &is2);


    /** @brief Escriu l'autor del parametre implicit
	    \pre cert
	    \post s'ha escrit l'autor del parametre implicit
    */    
    void autor_text() const;


    /** @brief Escriu el titol del text
	    \pre cert
	    \post s'ha escrit el titol del paràmetre implícit
    */   
    void titol_text() const; 

    
    /** @brief Escriu les frases del parametre implicit numerades a partir de l'1
	    \pre cert
	    \post s'ha escrit les frases del parametre implicit numerades a partir de l'1
    */    
    void contingut_text();
  
    
    /** @brief Escriu les frases del parametre implicit des de la x fins a la y incloses
	    \pre "iss" conte un interval (x,y) i ha de ser valid, 1 ≤ x ≤ y ≤ n
	    \post s'ha escrit les frases del parametre implicit des de la x fins a la y incloses
    */    
    void frases_xy(string &lin);

    
    /** @brief Escriu el nombre de frases del parametre implicit
	    \pre cert
	    \post s'ha escrit el nombre de frases del parametre implicit
    */    
    void nombre_frases() const;

    
    /** @brief Escriu el nombre de paraules del parametre implicit
	    \pre cert
	    \post s'ha escrit el nombre de paraules del parametre implicit
    */    
    void nombre_paraules_text() const;
    
    
    /** @brief Escriu el nombre de paraules del parametre implicit ordenades decreixentment per frequencia 
	    i en cas d'empat les escriu creixentment per llargada i despres alfabeticament
	    \pre cert
	    \post s'ha escrit el nombre de paraules del parametre implicit ordenades decreixentment per frequencia 
	    i en cas d'empat les escriu creixentment per llargada i despres alfabeticament
    */    
    void taula_frequencies();
  
    
    /** @brief Escriu les frases del parametre implicit que compleixen l'expressio "is"
	    \pre cert
	    \post s'ha escrit les frases del parametre implicit que compleixen l'expressio "is"
    */    
    void frases_expressio(const string &is);
    
    
    /** @brief Escriu les frases del parametre implicit que contenen les paraules de "is"
	    \pre cert
	    \post s'ha escrit les frases del parametre implicit que contenen les paraules de "is"
    */     
    void frases_paraula(string &lin);
    
      
};
#endif
 
