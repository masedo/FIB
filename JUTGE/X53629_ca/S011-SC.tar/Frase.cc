#include "Frase.hh"



//Operacions privades
string Frase::treu_signes_puntuacio(const string &s) {
  int n = s.length();
  string s1;
  for (int i = 0; i < n; ++i) {
    char c = s[i];
    if (c!='.' and c!=',' and c!=':' and c!=';' and c!='?' and c!='!' and c!='"' and c!= '{' and c!='}' and c != ' ') s1.push_back(c);  
  }
  return s1;
}

void Frase::expressions(const string &s, string &exp1, string &exp2, char &op) {
  stack<char> p;
  int n = 1;
  while (s[n] == ' ') ++n;
  p.push(s[n]);
  bool text = false;
  while(not p.empty()) {
    exp1.push_back(s[n]);
    if (s[n] == '{') text = true;
    if (s[n] == '}') text = false;
    ++n;
    while (s[n] == ' ' and not text) ++n;
    if (s[n]=='(' or s[n]=='{') p.push(s[n]);
    else if (s[n]==')' or s[n]=='}') {
	if (p.top() == '(' and s[n]==')') p.pop();
	else if (p.top() == '{' and s[n]=='}') p.pop();
      }
    if (p.empty()) exp1.push_back(s[n]);
  }
  ++n;
  while (s[n] == ' ') ++n;
  op = s[n];
  ++n;
  while (s[n] == ' ') ++n;
  p.push(s[n]);
  text = false;
  while(not p.empty()) {
    exp2.push_back(s[n]);
    if (s[n] == '{') text = true;
    if (s[n] == '}') text = false;
    ++n;
    while (s[n] == ' ' and not text) ++n;
    if (s[n]=='(' or s[n]=='{') p.push(s[n]);
    else if (s[n]==')' or s[n]=='}') {
	if (p.top() == '(' and s[n]==')') p.pop();
	else if (p.top() == '{' and s[n]=='}') p.pop();
      }
    if (p.empty()) exp2.push_back(s[n]);
  }
}



//Constructora
Frase::Frase() {
  nparaules = 0;
}



//Destructora
Frase::~Frase(){}



//Modificadores
void Frase::afegir_paraula(const string &s) {
  frase.push_back(s);
  
  string s1 = treu_signes_puntuacio(s);
  if (not s1.empty()) {
    map<string,int>::iterator it = paraules.find(s1);
    if (it != paraules.end()) ++(*it).second;
    else paraules.insert(make_pair(s1,1));  
  }
  
  ++nparaules;  
}

void Frase::substitueix(string &s1, string &s2) {
  map<string,int>::iterator it1 = paraules.find(s1);
  int apar = 0;
  if (it1 != paraules.end()) {
    map<string,int>::iterator it2 = paraules.find(s2);
    apar = (*it1).second;
    if (it2 != paraules.end()) (*it2).second += apar;
    else paraules.insert(make_pair(s2,apar));
    int n = 0, h = 0;
    while (n < apar) {
      if (treu_signes_puntuacio(frase[h]) == s1) {
	++n;
	char c = frase[h][frase[h].length()-1];
	frase[h] = s2;
	if (c=='.' or c==',' or c==':' or c==';' or c=='?' or c=='!')
	  frase[h].push_back(c); 
      }
      ++h;
    }
    paraules.erase(it1);
  }
}



//Consultores
bool Frase::compleix_expressio_simple(string &s) {
    s.erase(s.length()-1,s.length());
    s.erase(0,1);
    int n = s.length();
    vector<string> v;    
    string p;
    for (int i = 0; i < n; ++i) {
      if (s[i] != ' ') p.push_back(s[i]);
      else if (not p.empty()) {
	v.push_back(p);
	p.clear();
      }
    }
    if (not p.empty()) v.push_back(p);
    return hi_ha_paraules_conj(v);
}

bool Frase::compleix_expressio(const string &is) { //recursiva
  string exp1, exp2;
  char c;
  bool cond1, cond2;
  expressions(is,exp1,exp2,c);
  if (exp1[0] == '{') {
    cond1 = compleix_expressio_simple(exp1);
    if (cond1 and c == '|') return true;
    if (not cond1 and c == '&') return false;
    if (exp2[0] == '{') cond2 = compleix_expressio_simple(exp2);
    else cond2 = compleix_expressio(exp2);
    if (c == '|') return cond1 or cond2;
    else return cond1 and cond2;
  }
  else {
    cond1 = compleix_expressio(exp1);
    if (cond1 and c == '|') return true;
    if (not cond1 and c == '&') return false;
    if (exp2[0] == '{') cond2 = compleix_expressio_simple(exp2);
    else cond2 = compleix_expressio(exp2);
    if (c == '|') return cond1 or cond2;
    else return cond1 and cond2;
  }
}

string Frase::consulta_paraula(int n) const{
 return frase[n]; 
}

vector<pair<string,int> > Frase::calcular_freq() {
  map<string,int>::iterator it = paraules.begin();
  vector<pair<string,int> > V;
  while (it != paraules.end()) {
    V.push_back(*it);
    ++it;
  }
  return V;
}

bool Frase::hi_ha_paraules_seq(const vector<string> &v) {
  if (hi_ha_paraules_conj(v)) {
    int N = frase.size(), n = v.size(), j = 0;
    while (treu_signes_puntuacio(frase[j]) != v[0] and j < N) ++j;
    if ((j+n-1) < N) {
      bool t = true;
      int h = 1;
      ++j;
      while (t and h < n) {
	if (treu_signes_puntuacio(frase[j]) != v[h]) t = false;
	++h; 
	++j;
      }
      return t;      
    }
    else return false;    
  }
  else return false;  
}

bool Frase::hi_ha_paraules_conj(const vector<string> &v) {
  int n = v.size(), i = 0;
  bool trobades = true;
  while (trobades and i < n) {
    map<string,int>::iterator it = paraules.find(treu_signes_puntuacio(v[i]));
    if (it == paraules.end()) trobades = false;
    ++i;
  }
  return trobades;
}
  
int Frase::nombre_paraules() const{
  return nparaules;  
}

bool Frase::operator<(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules(), z;
  if (x<=y) z = x;
  else z = y;
  for (int i=0;i<z;++i) {
    if (frase[i] != f.consulta_paraula(i)) return frase[i] < f.consulta_paraula(i);
  }
  return x<y;
}

bool Frase::operator!=(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules();
  if (x != y) return true;
  for (int i=0;i<x;++i) {
    if (frase[i] != f.consulta_paraula(i)) return true;
  }
  return false;
}

bool Frase::operator==(const Frase&f) const {
  int x = frase.size(), y = f.nombre_paraules();
  if (x != y) return false;
  for (int i=0;i<x;++i) {
    if (frase[i] != f.consulta_paraula(i)) return false;
  }
  return true;
}



//Lectura i escriptura
void Frase::escriure_frase() const{
  int n = frase.size();
  for (int i = 0; i < n; ++i) {
    if (i > 0) cout << " ";
    cout << frase[i];
  }
}