#ifndef ConjuntFrase_HH
#define ConjuntFrase_HH

#include "Frase.hh"
#ifndef NO_DIAGRAM
#include <vector>
#endif

class ConjuntFrase {
  
  // Tipus de modul: dades
  // Descripcio del tipus: Conté una seqüència de frases
    
private:
  
  vector<Frase> c_frase;

  /*
    Invariant de la representació:
    -"c_frase" conté una seqüència de frases
  */

  
  
public:
    //Constructora

    /** @brief Es crea un conjunt de frases buit
	    \pre cert
	    \post El resultat es un conjunt de frases buit
    */  
    ConjuntFrase();

    
    
    //Destructora

    ~ConjuntFrase();
    
    
    
    //Modificadores
    
    /** @brief Afegeix una frase al conjunt
	    \pre cert
	    \post S'ha afegit una frase al paràmetre impllícit
    */ 
    void afegir_frase(const Frase &s);
    
    
    
    //Consultores
    /** @brief Retorna la frase x-èssima del conjunt
	    \pre 0 < "x" <= # de frases del P.I.
	    \post El resultat és la frase x-èssima del P.I.
    */ 
    Frase consultar_frase(int x) const;
    
    /** @brief Retorna el nombre de frases del conjunt
	    \pre Cert
	    \post El resuktat és el nombre de frases que té
		  el paràmetre impllícit
    */ 
    int nombre_frases() const;
              
    /** @brief Operador igual
	    \pre cert
	    \post El resultat es cert si "f" conté la mateixa
		  seqüència de frases que el paràmetre impllícit  
    */ 
    bool operator==(const ConjuntFrase &f) const;  
    
    /** @brief 
	    \pre 
	    \post   
    */ 
    bool operator<(const ConjuntFrase &f) const; 
 
    /** @brief 
	    \pre 
	    \post   
    */ 
    void escriure_conjunt_frase() const;
    
    
    
    //Lectura i escritura
    /** @brief 
	    \pre 
	    \post   
    */ 
};
#endif
