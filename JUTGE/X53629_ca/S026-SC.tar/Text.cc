#include "Text.hh"



//Operacions privades
struct par_freq { 
  int freq;
  string par;
  bool operator<(const par_freq &p) const {
    if (freq != p.freq) return freq > p.freq;
    else if (par.length() != p.par.length()) return par.length() < p.par.length();
    else return par < p.par;
  }
};


string Text::treure_cometes2(string &s) {
  int n = s.length();
  if (s[n-1] == '"') s.erase(n-1);
  if (s[0] == '"') s.erase(s.begin());
  return s;
} 



//Constructora
Text::Text() {
  taula_actualitzada = false;
}



//Destructora
Text::~Text(){}



//Modificadores
void Text::substitueix_paraula(string& p1, string& p2) {
  int n = contingut.nombre_frases();
  for (int i = 0; i < n; ++i) {cout<<i;contingut.consultar_frase(i+1).substitueix(p1,p2);}
  taula_actualitzada = false;
  calcular_taula();
}

void Text::calcular_taula() {
  if (not taula_actualitzada) {
    map<string,int> buida;
    taula = buida;
    int n = contingut.nombre_frases();
    for (int i = 0; i < n; ++i) {
      vector<pair<string,int> > vec;
      vec = contingut.consultar_frase(i+1).calcular_freq();
      int r = vec.size();
      for (int j = 0; j < r; ++j) {
	map<string,int>::iterator it = taula.find(vec[j].first);
	if (it != taula.end()) (*it).second += vec[j].second;
	else taula.insert(vec[j]);
      }
    }
    set<par_freq> S;
    map<string,int>::iterator it = taula.begin();
    while (it != taula.end()) {
      par_freq g;
      g.par = (*it).first;
      g.freq = (*it).second;
      S.insert(g);
      ++it;
    }
    taula_freq = S;   
    taula_actualitzada = true;
  }
}

//Consultores
Frase Text::consultar_autor() const{
  return autor;
}

ConjuntFrase Text::consultar_titol() const{
  return titol;
}

ConjuntFrase Text::contingut_interval(int x, int y) const{
  ConjuntFrase aux;
  int i = 0;
  for (int j=x-1;j<y;++j) {
    aux.afegir_frase(contingut.consultar_frase(j+1));
    ++i;
  }
  return aux;
}

int Text::consultar_frases() const{
  return contingut.nombre_frases();
}

int Text::consultar_paraules_text() const{
  int suma = 0, n = contingut.nombre_frases();
  for (int i = 0; i < n; ++i) {
    suma += contingut.consultar_frase(i+1).nombre_paraules();
  }
  return suma;
}

bool Text::hi_ha_paraula(const string &s) {
  int n = titol.nombre_frases(), i = 0;
  bool trobada = false;
  vector<string> v;
  v.push_back(s);
  while (not trobada and i < n) {
    if (titol.consultar_frase(i+1).hi_ha_paraules_conj(v)) trobada = true;
    ++i;
  }
  if (not trobada) {
    trobada = autor.hi_ha_paraules_conj(v);
  }
  i = 0;
  n = contingut.nombre_frases();
  while (not trobada and i < n) {
    if (contingut.consultar_frase(i+1).hi_ha_paraules_conj(v)) trobada = true;
    ++i;
  }
  return trobada;
}


bool Text::interval_correcte(int x, int y) const{
  return (x>0 and x<=y and y<=contingut.nombre_frases());
}

bool Text::operator<(const Text &t) const {
  ConjuntFrase tit = t.consultar_titol();
  if (autor != t.consultar_autor()) {
    int x = contingut.nombre_frases(), y = tit.nombre_frases(), z;
    if (x < y) z = x;
    else z = y;
    for (int i = 0; i < z; ++i) {
      if (titol.consultar_frase(i+1) != tit.consultar_frase(i+1)) return titol.consultar_frase(i+1) < tit.consultar_frase(i+1);
    }
    return x < y;
  }
  else return autor < t.consultar_autor();
}



//Lectura i escritura
void Text::llegir_text(istream &is1, istream &is2) {
  string p;
  Frase f; 
  while (is1>>p) {
    int s = p.length()-1;
    if (p[0] == '"' or p[s] == '"') p = treure_cometes2(p);
    f.afegir_paraula(p);
    s = p.length()-1;
    if (p[s] == '.' or p[s] == '?' or p[s] == '!') {
      titol.afegir_frase(f);
      Frase f1;
      f = f1;
    }
  }
  titol.afegir_frase(f);
    
  is2>>p;
  while (is2>>p) {
    int s = p.length()-1;
    if (p[0] == '"' or p[s] == '"') p = treure_cometes2(p);
    autor.afegir_paraula(p);
  }
  
  Frase f1;
  bool ficada = false;
  while (cin >> p and p != "****") {
    f1.afegir_paraula(p);
    ficada = false;
    int s = p.length()-1;
    if (p[s] == '.' or p[s] == '?' or p[s] == '!') {
      contingut.afegir_frase(f1);
      ficada = true;
      Frase f2;
      f1 = f2;
    }
  }
  if (not ficada and p!="****") contingut.afegir_frase(f1);
}

void Text::autor_text() {  //asuhflashglkashg
  autor.escriure_frase();
}

void Text::contingut_text() {
  int n = contingut.nombre_frases();
  for (int i = 0; i < n; ++i) {
    cout<<i+1<<" ";
    contingut.consultar_frase(i+1).escriure_frase();
    cout<<endl;
  }
}

void Text::frases_xy(string &lin) {
  istringstream is(lin);
  string p;
  is>>p;
  int x,y;
  is>>x; 
  is>>y;
  if (interval_correcte(x,y)) {
    for (int i = x-1; i < y; ++i) {
      cout << i+1 << " ";
      contingut.consultar_frase(i+1).escriure_frase();
      cout << endl;
    }  
  }
  else cout<<"error"<<endl;
}  

  
void Text::taula_frequencies() {
  if (not taula_actualitzada) calcular_taula();
  set<par_freq>::iterator it = taula_freq.begin();  
  while (it != taula_freq.end()) {
    cout << (*it).par <<  " " << (*it).freq << endl;
    ++it;
  }
}
  
void Text::frases_expressio(const string &is) {
  int r = contingut.nombre_frases();
  for (int i = 0; i < r; ++i) {
    string s1 = is;
    if (contingut.consultar_frase(i+1).compleix_expressio(s1)) {
      cout << i+1 << " ";
      contingut.consultar_frase(i+1).escriure_frase();
      cout << endl;
    }
  }
}

void Text::frases_paraula(string &lin) {
 istringstream is(lin);
 string s;
 is >> s;
 vector<string> paraules;
 is>>s;
 while (s != "?") {
   paraules.push_back(s);
   is>>s;
 }
 int n = paraules.size();
 paraules[0] = treure_cometes2(paraules[0]);
 paraules[n-1] = treure_cometes2(paraules[n-1]);
 n = contingut.nombre_frases();
 for (int i = 0; i < n; ++i) {
   if (contingut.consultar_frase(i+1).hi_ha_paraules_seq(paraules)) {
     cout << i+1 << " ";
     contingut.consultar_frase(i+1).escriure_frase();
     cout << endl;
   }   
 }  
}