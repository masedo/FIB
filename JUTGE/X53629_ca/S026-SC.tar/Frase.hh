#ifndef FRASE_HH
#define FRASE_HH

#ifndef NO_DIAGRAM
#include <string>
#include <vector>
#include <iostream>
#include <map>
#include <stack>
#endif
using namespace std;

class Frase {
  
  // Tipus de modul: dades
  // Descripcio del tipus: conté totes les paraules d'una frase
    
private:
  
  map<string, int> paraules;
  vector<string> frase;
  int nparaules;

  /*
    Invariant de la representació:
    - Les paraules són la clau i les seves freqüències el valor
      del map "paraules". 
    - Les paraules del map "paraules" es representen sense signes de 
      puntuació i amb minúscules.
    - Al vector "frase" s'hi emmagatzemen totes les paraules originals
      amb els signes de puntuació.
  */

  
  /** @brief Treu els signes de puntuació d'una paraula
	  \pre Cert
	  \post El resultat és un string igual a "s" sense signes de puntuació
  */
  static string treu_signes_puntuacio(const string &s);
    
  /** @brief Separa la primera i la segona expressió i el operador d'una expressió que conté aquests
	  \pre L'expressió té una primera expressió, una segona i un operador '|' o un operador '&'
	  \post "exp1" pren el valor de la primera expressió, "exp2" pren el valor de la segona expressió
		i el char "op" pren el valor de l'operador
  */
  static void expressions(const string &s, string &exp1, string &exp2, char &op);
  
  
  
public:
    //Constructora

    /** @brief Es crea una frase buida
	    \pre cert
	    \post El resultat es una frase buida
    */  
    Frase();

    
    
    //Destructora

    ~Frase();
       
    
    
    //Modificadores
    
    /** @brief S'afegeix una paraula al parametre implicit
	    \pre cert
	    \post l'string "s" s'ha afegit al parametre implicit
    */    
    void afegir_paraula(const string &s);
        
    /** @brief Substitueix totes les paraules iguals a "s1" per "s2"
	    \pre Cert
	    \post S'han substituït totes les paraules iguals a "s1"
		  del paràmetre implícit per "s2"
    */    
    void substitueix(string &s1, string &s2);    
    
    
    
    //Consultores
    /** @brief Diu si la frase conté el conjunt de paraules "s"
	  \pre Cert
	  \post El resultat és cert si el P.I. conté el conjunt de paraules que està a "s"
      */
    bool compleix_expressio_simple(string &s);    
    
    /** @brief Diu si una paraula compleix una expressió "is"
	    \pre Cert
	    \post El resultat és cert si el paràmetre implícit compleix l'expressió
		  "is". El resultat és fals altrament.
    */ 
    bool compleix_expressio(string &is);
    
    /** @brief Retorna la paraula n-èssima de la frase
	    \pre n <= nombre de paraules del p.i
	    \post El resultat és la paraula n-èssima del paràmetre implícit
    */    
    string consulta_paraula(int n) const ;    
 
    /** @brief Calcula la freqüència de cada paraula de la frase
	    \pre Cert
	    \post El resultat és un vector de parells amb cada paraula del
		  paràmetre implícit amb la seva freqüència
    */    
    vector<pair<string,int> > calcular_freq();
    
    /** @brief Diu si la seqüència de paraules de "v" esta a la frase
	    \pre Cert
	    \post El resultat és cert si la seqüència de paraules "v" està
		  al paràmetre implícit.
    */    
    bool hi_ha_paraules_seq(const vector<string> &v);

    /** @brief Diu si les paraules del conjunt "v" estan a la frase
	    \pre Cert
	    \post El resultat és cert si el conjunt de paraules "v" pertany
		  al paràmetre implícit
    */    
    bool hi_ha_paraules_conj(const vector<string> &v);
    
    /** @brief Diu el nombre de paraules que té la frase
	    \pre cert.
	    \post El resultat és el nombre de paraules del P.I
    */    
    int nombre_paraules() const; 
      
    /** @brief Operador menor
	    \pre Cert
	    \post El resultat és cert si el paràmetre implícit és més petit 
		  alfabeticament que la frase "f"
    */
    bool operator<(const Frase&f) const;
    
    /** @brief Operador diferent
	    \pre Cert
	    \post El resultat és cert si el paràmetre implícit és diferent que 
		  la frase "f"
    */    
    bool operator!=(const Frase&f) const;
  
    /** @brief Operador igual
	    \pre Cert
	    \post El resultat és cert si el paràmetre implícit és igual a la
		  frase "f"
    */    
    bool operator==(const Frase&f) const;    

              
    
    // Lectura i escriptura
    
    /** @brief Escriu el conjunt de paraules del paràmetre implicit
	    \pre cert
	    \post s'ha escrit totes les paraules del parametre implicit
    */   
    void escriure_frase() const;   
    
};
#endif