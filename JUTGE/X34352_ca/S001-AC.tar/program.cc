#include <iostream>
#include <map>
#include <string>
using namespace std;


int main() {
  map<string, int> Paraules;
  char c;
  
  while (cin >> c) {
    string s;
    cin >> s;
    map<string, int>::iterator it = Paraules.find(s);
    
    if (c == 'a') {
      if (it == Paraules.end()) 
	Paraules.insert(pair<string, int>(s,1));
      else (*it).second++;
    }
	
    else {
      if (it == Paraules.end()) cout << "0" << endl;
      else cout << (*it).second << endl;
    }
  }
}