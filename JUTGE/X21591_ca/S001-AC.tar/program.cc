#include "CuaIOEstudiant.hh"
#include "Estudiant.hh"
#include <queue>
using namespace std;


int main() {
  queue<Estudiant> Q;
  LlegirCuaEstudiant(Q);
  int dni;
  cin >> dni;
  
  EscriureCuaEstudiant(Q);
  
  bool trobat = false, nota = false;  
  while (not Q.empty() and not trobat) {
    if (Q.front().consultar_DNI() == dni) {
      trobat = true;
      if (Q.front().te_nota()) nota = true;
    }
    else Q.pop();
  }
  if (trobat and nota) cout << "La nota es " << Q.front().consultar_nota() << endl;
  else if (trobat) cout << "No te nota" << endl;
  else cout << "No trobat" << endl;
}