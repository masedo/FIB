#include "CuaIOEstudiant.hh"


void LlegirCuaEstudiant(queue<Estudiant> &q) {
  int n;
  cin >> n;
  
  for (int i = 0; i < n; ++i) {
    Estudiant E;
    E.llegir();
    q.push(E);
  }  
}

void EscriureCuaEstudiant(queue<Estudiant> q) {
  while (not q.empty()) {
    q.front().escriure();
    q.pop();
  }  
}

