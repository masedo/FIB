#include "Estudiant.hh"
#include <queue>
#include <iostream>
using namespace std;

void LlegirCuaEstudiant(queue<Estudiant> &q);
/*Pre: hi ha preparat al canal estandard d'entrada un enter n seguit d'n estudiants */
/*Post: el paràmetre implícit passa a tenir els n estudiants llegits pel canal d'entrada */

void EscriureCuaEstudiant(queue<Estudiant> q);
/*Pre: cert */
/*Post: s'han escrit els estudiants del paràmetre implicit al canal estandard de sortida */
