#include <iostream>
#include "Estudiant.hh"
#include <list>
using namespace std;


void llegir(list<Estudiant> &L) {
  Estudiant E;
  E.llegir();
  list<Estudiant>::iterator it = L.begin();
  while (E.consultar_DNI() != 0 and E.consultar_nota() != 0) {
    L.insert(it,E);
    E.llegir();
  }
}

void buscar(const list<Estudiant> &L, int dni, int &n) {
  n = 0;
  list<Estudiant>::const_iterator it = L.begin();
  while (it != L.end()) {
    if ((*it).consultar_DNI() == dni) ++n;
    ++it;
  }
}

int main() {
  list<Estudiant> L;
  llegir(L);
  int dni, n;
  cin >> dni;
  buscar(L,dni,n);
  cout << n << endl;
}
  
