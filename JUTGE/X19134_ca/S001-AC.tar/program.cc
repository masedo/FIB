#include <iostream>
#include <list>
using namespace std;


void Llegir_llista(list< pair<int,int> > &L) {
  list< pair<int,int> >::iterator it = L.begin();
  pair<int,int> fin(0,0);
  pair<int,int> P;
  cin >> P.first >> P.second;

  while (P != fin) {
    L.insert(it,P);
    cin >> P.first >> P.second;
  }
}

void Buscar(const list< pair<int,int> > &L, int n, int &apar, int &suma) {
  apar = 0;
  suma = 0;
  list< pair<int,int> >::const_iterator it = L.begin();
  while (it != L.end()) {
    if ((*it).first == n) {
      ++apar;
      suma += (*it).second;
    }
    ++it;
  }
}

int main() {
  list< pair<int,int> > L;
  Llegir_llista(L);
  int n, apar, suma;
  cin >> n;
  Buscar(L,n,apar,suma);
  cout << n << " " << apar << " " << suma << endl;
}
  
  
  
  