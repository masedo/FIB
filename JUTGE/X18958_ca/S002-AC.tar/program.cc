#include "PilaIOParInt.hh"
#include "ParInt.hh"
#include <iostream>
using namespace std;


int main() {
  stack<ParInt> P;
  llegirPilaParInt(P);
  
  int n;
  cin >> n;
  
  escriurePilaParInt(P);
  if (not P.empty() and P.top().primer() == n) cout << P.top().segon() << endl;
  else cout << "No trobat" << endl;
}